import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';
import { Employee2 } from '../Employee2';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  createdEmployee2: Employee2;
service:EmpServiceService;
createdFlag:boolean=false;

  constructor(service:EmpServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
add(data:any){
  this.createdEmployee2=new Employee2(data.dptId,data.dptName);
  this.service.add(this.createdEmployee2);
  this.createdFlag=true;
}
}
