import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import { DisplayComponent } from './display/display.component';
import { UpdateComponent } from './update/update.component';


const routes: Routes = [
  {
    path:'app-create-emp',
    component: AddComponent
  },

  {
    path:'app-list-emp',
    component:DisplayComponent},

    {
      path:'app-update-emp',
      component:UpdateComponent
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
