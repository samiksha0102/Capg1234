import { Component, OnInit } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';
import { Employee2 } from '../Employee2';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  service:EmpServiceService ;

  constructor(service:EmpServiceService ){
 this.service=service;
  }
 
 employees:Employee2[]=[]
 delete(dptId:number){
   this.service.delete(dptId);
   this.employees=this.service.getEmployees();
 }
 column:string="id";
 order:boolean=true;
 sort(column:string){
  if(this.column==column )
  {
    this.order=!this.order;
  }else{
    this.order=true;
    this.column=column;
  }

 }
   ngOnInit() {
 this.service.fetchEmployees();
 this.employees=this.service.getEmployees();
 
   }
 

}
