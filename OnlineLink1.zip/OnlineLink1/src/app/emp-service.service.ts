import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee2 } from './Employee2';



@Injectable({
  providedIn: 'root'
})

export class EmpServiceService {


  http: HttpClient;
  employees: Employee2[] = [];

  constructor(http: HttpClient) {
    this.http = http;
  }

  getEmployees(): Employee2[] {          //get method return type Employee array
    return this.employees;            //getting all the data
  }



  convert(data: any) {
    for (let o of data) {
      let e = new Employee2(o.dptId, o.dptName);
      this.employees.push(e);
    }
  }


  fetched: boolean = false;
  fetchEmployees() {
    this.http.get('./assets/department.json')
      .subscribe(                                         //fetching data from json file using http
        data => {                                          //reading json file and storing it in a variable data
          if (!this.fetched) {
            this.convert(data);
            this.fetched = true;
          }
        });

  }
  delete(dptId: number) {

    let foundIndex: number = -1;
    for (let i = 0; i < this.employees.length; i++) {
      let c = this.employees[i];
      if (dptId == c.dptId) {
        foundIndex = i;
        break;
      }
    } this.employees.splice(foundIndex, 1);           //Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.
  }

  add(e: Employee2) {
    this.employees.push(e);
  }


  Change(e: Employee2) {
    let id = e.dptId;

    for (let i = 0; i < this.employees.length; i++) {
      let c = this.employees[i];

      if (id == c.dptId)
       {
        console.log("*************>" +id)
        this.delete(id);
        this.add(e);
        break;
      }
      else 
      { window.alert("id not exist") }

    }
  }
}
