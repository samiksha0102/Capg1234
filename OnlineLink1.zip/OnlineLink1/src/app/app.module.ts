import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {FormsModule} from'@angular/forms';
import { DisplayComponent } from './display/display.component';
import { AddComponent } from './add/add.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { EmpServiceService } from './emp-service.service';
import { UpdateComponent } from './update/update.component';
import { OrderByPipe } from './order-by.pipe';

@NgModule({
  declarations: [
    AppComponent,
     DisplayComponent,
    AddComponent,
    UpdateComponent,
    OrderByPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,EmpServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
