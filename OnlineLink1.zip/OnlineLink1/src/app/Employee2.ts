export class Employee2{
    dptName:string;
    dptId:number;
constructor(dptId:number,
    dptName:string)
{
    this.dptId=dptId;
    this.dptName=dptName

}
}