import { Component, OnInit } from '@angular/core';
import { Employee2 } from '../Employee2';
import { EmpServiceService } from '../emp-service.service';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  service:EmpServiceService ;
  updateEmp: Employee2;
updatedFlag:boolean=false;
constructor(service:EmpServiceService) { 
  this.service=service;
}

  ngOnInit() {
  }

  Change(data:any)
  {
    this.updateEmp=new Employee2(data.dptId,data.dptName);
    this.service.Change(this.updateEmp);
    this.updatedFlag=true;
  }


 
}
